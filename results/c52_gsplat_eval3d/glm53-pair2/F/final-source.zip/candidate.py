"""Lean world-space eval3d 3DGS rasterization: forward plus full six-way VJP.

Semantically equivalent to the parent path
(gsplat.cuda._wrapper.rasterize_to_pixels_eval3d with camera_model="pinhole",
rolling_shutter=GLOBAL, use_hit_distance=False, followed by
torch.autograd.grad w.r.t. means/quats/scales/colors/opacities/backgrounds),
but the host-side work is reduced: no re-validation of static metadata, no
autograd graph, single fused extension call for the forward and one for the
backward, and the backgrounds gradient is a single small reduction.
Every call performs the actual forward and backward computation on the
provided inputs.
"""

_STATE = {}


def _state():
    """Lazily bind the compiled extension entry points and static enum objects."""
    if _STATE:
        return _STATE
    from gsplat.cuda._wrapper import (
        FThetaCameraDistortionParameters,
        RollingShutterType,
        UnscentedTransformParameters,
        _make_lazy_cuda_func,
        _make_lazy_cuda_obj,
    )

    _STATE["fwd"] = _make_lazy_cuda_func("rasterize_to_pixels_from_world_3dgs_fwd")
    _STATE["bwd"] = _make_lazy_cuda_func("rasterize_to_pixels_from_world_3dgs_bwd")
    _STATE["ut"] = UnscentedTransformParameters()
    _STATE["ftheta"] = FThetaCameraDistortionParameters()
    _STATE["pinhole"] = _make_lazy_cuda_obj("CameraModelType.PINHOLE")
    _STATE["global_shutter"] = RollingShutterType.GLOBAL
    return _STATE


_SUPPORTED_CHANNELS = (
    1, 2, 3, 4, 5, 8, 9, 16, 17, 24, 32, 33, 64, 65, 128, 129, 256, 257, 512, 513,
)


def _c(t):
    """Cheap contiguity guard."""
    return t if t.is_contiguous() else t.contiguous()


def run(inputs, meta, weights):
    import torch

    st = _state()
    fwd = st["fwd"]
    bwd = st["bwd"]
    ut = st["ut"]
    ftheta = st["ftheta"]
    pinhole = st["pinhole"]
    rs_global = st["global_shutter"]

    means = _c(inputs["means"])
    quats = _c(inputs["quats"])
    scales = _c(inputs["scales"])
    opacities = _c(inputs["opacities"])
    backgrounds = inputs["backgrounds"]
    if backgrounds is not None:
        backgrounds = _c(backgrounds)
    viewmats = _c(meta["viewmats"])
    Ks = _c(meta["Ks"])
    width = meta["image_width"]
    height = meta["image_height"]
    tile_size = meta["tile_size"]
    tile_offsets = _c(meta["isect_offsets"])
    flatten_ids = _c(meta["flatten_ids"])

    colors = _c(inputs["colors"])
    channels = colors.size(-1)
    if channels not in _SUPPORTED_CHANNELS:
        # Same channel-padding semantics as the parent wrapper.
        padded = (1 << (channels - 1).bit_length()) - channels
        zeros_c = torch.zeros(
            (*colors.shape[:-1], padded), dtype=colors.dtype, device=colors.device
        )
        colors = torch.cat([colors[..., :-1], zeros_c, colors[..., -1:]], dim=-1)
        if backgrounds is not None:
            zeros_b = torch.zeros(
                (*backgrounds.shape[:-1], padded),
                dtype=backgrounds.dtype,
                device=backgrounds.device,
            )
            backgrounds = torch.cat([backgrounds, zeros_b], dim=-1)

    renders, alphas, last_ids = fwd(
        means,
        quats,
        scales,
        colors,
        opacities,
        backgrounds,
        None,  # masks
        width,
        height,
        tile_size,
        viewmats,
        None,  # viewmats_rs
        Ks,
        pinhole,
        ut,
        rs_global,
        None,  # rays
        None,  # radial_coeffs
        None,  # tangential_coeffs
        None,  # thin_prism_coeffs
        ftheta,
        None,  # lidar_coeffs
        None,  # external_distortion_coeffs
        tile_offsets,
        flatten_ids,
        False,  # use_hit_distance
        None,  # sample_counts
        None,  # render_normals
    )

    if channels not in _SUPPORTED_CHANNELS:
        renders = torch.cat(
            [renders[..., : -padded - 1], renders[..., -1:]], dim=-1
        )

    v_render_colors = weights[0]
    v_render_alphas = weights[1]
    if not v_render_colors.is_contiguous():
        v_render_colors = v_render_colors.contiguous()
    if not v_render_alphas.is_contiguous():
        v_render_alphas = v_render_alphas.contiguous()

    v_means, v_quats, v_scales, v_colors, v_opacities, _v_rays = bwd(
        means,
        quats,
        scales,
        colors,
        opacities,
        backgrounds,
        None,  # masks
        width,
        height,
        tile_size,
        viewmats,
        None,  # viewmats_rs
        Ks,
        pinhole,
        ut,
        rs_global,
        None,  # rays
        None,  # radial_coeffs
        None,  # tangential_coeffs
        None,  # thin_prism_coeffs
        ftheta,
        None,  # lidar_coeffs
        None,  # external_distortion_coeffs
        tile_offsets,
        flatten_ids,
        False,  # use_hit_distance
        alphas,
        last_ids,
        v_render_colors,
        v_render_alphas,
        None,  # v_render_normals
    )

    if channels not in _SUPPORTED_CHANNELS:
        v_colors = torch.cat(
            [v_colors[..., : -padded - 1], v_colors[..., -1:]], dim=-1
        )

    # Backgrounds gradient: d(out)/d(backgrounds) = (1 - alpha) per pixel.
    v_backgrounds = (v_render_colors * (1.0 - alphas)).sum(dim=(-3, -2))

    return (renders, alphas), (
        v_means,
        v_quats,
        v_scales,
        v_colors,
        v_opacities,
        v_backgrounds,
    )
