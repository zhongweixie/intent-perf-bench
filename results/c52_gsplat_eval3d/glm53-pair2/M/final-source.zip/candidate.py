"""Optimized world-space eval3d RGB/alpha full forward + VJP entry.

Calls the gsplat CUDA ops directly (same kernels / same math) and skips the
autograd graph and the heavy Python wrapper. Semantics (channel padding,
truncation, camera model, background gradient) match the parent implementation.
"""
import torch

_SUPPORTED = (1, 2, 3, 4, 5, 8, 9, 16, 17, 24, 32, 33, 64, 65, 128, 129,
              256, 257, 512, 513)
_st = None


def _setup():
    global _st
    from gsplat.cuda._wrapper import (_make_lazy_cuda_func,
                                      _make_lazy_cuda_obj,
                                      UnscentedTransformParameters,
                                      FThetaCameraDistortionParameters,
                                      RollingShutterType)
    _st = (
        _make_lazy_cuda_func("rasterize_to_pixels_from_world_3dgs_fwd"),
        _make_lazy_cuda_func("rasterize_to_pixels_from_world_3dgs_bwd"),
        _make_lazy_cuda_obj("CameraModelType.PINHOLE"),
        UnscentedTransformParameters(),
        FThetaCameraDistortionParameters(),
        RollingShutterType.GLOBAL,
    )
    return _st


def run(inputs, meta, weights):
    if _st is None:
        _setup()
    fwd, bwd, pinhole, ut, ftheta, rs_global = _st

    means = inputs["means"]
    quats = inputs["quats"]
    scales = inputs["scales"]
    colors = inputs["colors"]
    opacities = inputs["opacities"]
    backgrounds = inputs["backgrounds"]
    viewmats = meta["viewmats"]
    Ks = meta["Ks"]
    width = meta["image_width"]
    height = meta["image_height"]
    tile_size = meta["tile_size"]
    isect_offsets = meta["isect_offsets"]
    flatten_ids = meta["flatten_ids"]

    if not colors.is_contiguous():
        colors = colors.contiguous()
    if not backgrounds.is_contiguous():
        backgrounds = backgrounds.contiguous()
    if not means.is_contiguous():
        means = means.contiguous()
    if not quats.is_contiguous():
        quats = quats.contiguous()
    if not scales.is_contiguous():
        scales = scales.contiguous()
    if not opacities.is_contiguous():
        opacities = opacities.contiguous()
    if not viewmats.is_contiguous():
        viewmats = viewmats.contiguous()
    if not Ks.is_contiguous():
        Ks = Ks.contiguous()
    if not isect_offsets.is_contiguous():
        isect_offsets = isect_offsets.contiguous()
    if not flatten_ids.is_contiguous():
        flatten_ids = flatten_ids.contiguous()

    # channel padding (same rule as the parent wrapper)
    D = colors.shape[-1]
    padded = 0
    if D not in _SUPPORTED:
        padded = (1 << (D - 1).bit_length()) - D
        zeros = torch.zeros(
            (colors.shape[:-1] + (padded,)),
            dtype=colors.dtype,
            device=colors.device,
        )
        colors = torch.cat([colors[..., :-1], zeros, colors[..., -1:]], dim=-1)
        if backgrounds is not None:
            zeros_b = torch.zeros(
                (backgrounds.shape[:-1] + (padded,)),
                dtype=backgrounds.dtype,
                device=backgrounds.device,
            )
            backgrounds = torch.cat(
                [backgrounds[..., :-1], zeros_b, backgrounds[..., -1:]], dim=-1
            )

    render_colors, render_alphas, last_ids = fwd(
        means, quats, scales, colors, opacities, backgrounds, None,
        width, height, tile_size, viewmats, None, Ks, pinhole, ut, rs_global,
        None, None, None, None, ftheta, None, None,
        isect_offsets, flatten_ids, False, None, None,
    )

    w_c = weights[0]
    w_a = weights[1]
    if not w_c.is_contiguous():
        w_c = w_c.contiguous()
    if not w_a.is_contiguous():
        w_a = w_a.contiguous()

    v_means, v_quats, v_scales, v_colors, v_opacities, _v_rays = bwd(
        means, quats, scales, colors, opacities, backgrounds, None,
        width, height, tile_size, viewmats, None, Ks, pinhole, ut, rs_global,
        None, None, None, None, ftheta, None, None,
        isect_offsets, flatten_ids, False, render_alphas, last_ids,
        w_c, w_a, None,
    )

    if padded:
        # trim the inserted zero channels (identical to parent wrapper)
        render_colors = torch.cat(
            [render_colors[..., : D - 1], render_colors[..., -1:]], dim=-1
        )
        v_colors = torch.cat([v_colors[..., : D - 1], v_colors[..., -1:]], dim=-1)

    v_backgrounds = (w_c * (1.0 - render_alphas)).sum(dim=(-3, -2))

    return (
        (render_colors, render_alphas),
        (v_means, v_quats, v_scales, v_colors, v_opacities, v_backgrounds),
    )
