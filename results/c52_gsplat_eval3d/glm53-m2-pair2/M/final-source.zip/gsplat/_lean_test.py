import sys, torch
sys.path.insert(0,'/task')
import gsplat.cuda._wrapper as W
print('names:', [n for n in dir(W) if 'Unscented' in n or 'FTheta' in n or n=='RollingShutterType'])
print('cmt:', W._make_lazy_cuda_obj("CameraModelType.PINHOLE"))
ut = W.UnscentedTransformParameters()
ft = W.FThetaCameraDistortionParameters()
print('ut ok', 'ft ok')
ops = torch.ops.gsplat
d = torch.load('/contract/inputs.pt',map_location='cuda',weights_only=False)
NAMES=['means','quats','scales','colors','opacities','backgrounds']
def lean(inputs, meta, weights):
    means,quats,scales,colors,opacities,backgrounds = (inputs[n] for n in NAMES)
    viewmats=meta['viewmats'];Ks=meta['Ks']
    W_=meta['image_width'];H=meta['image_height'];ts=meta['tile_size']
    io=meta['isect_offsets'];fi=meta['flatten_ids']
    rc, ra, last = ops.rasterize_to_pixels_from_world_3dgs_fwd(
        means,quats,scales,colors,opacities,backgrounds,None,W_,H,ts,
        viewmats,None,Ks,W._make_lazy_cuda_obj("CameraModelType.PINHOLE"),ut,
        W.RollingShutterType.GLOBAL,None,None,None,None,ft,None,None,
        io,fi,False,None,None)
    vm,vq,vsc,vc,vo,vrays = ops.rasterize_to_pixels_from_world_3dgs_bwd(
        means,quats,scales,colors,opacities,backgrounds,None,W_,H,ts,
        viewmats,None,Ks,W._make_lazy_cuda_obj("CameraModelType.PINHOLE"),ut,
        W.RollingShutterType.GLOBAL,None,None,None,None,ft,None,None,
        io,fi,False,ra,last,weights[0],weights[1],None)
    vbg = (weights[0]*(1.0-ra.float())).sum(dim=(-3,-2))
    return (rc,ra),(vm,vq,vsc,vc,vo,vbg)
from gsplat.cuda._wrapper import rasterize_to_pixels_eval3d, RollingShutterType
for row in d:
    inputs={k:v.detach().clone().requires_grad_(True) for k,v in row['inputs'].items()}
    outputs=rasterize_to_pixels_eval3d(**inputs,**row['meta'],camera_model='pinhole',rolling_shutter=RollingShutterType.GLOBAL,use_hit_distance=False)
    g=torch.autograd.grad(outputs,tuple(inputs[n] for n in NAMES),grad_outputs=row['weights'])
    o2,g2=lean({k:v.detach() for k,v in row['inputs'].items()},row['meta'],row['weights'])
    m1=(outputs[0]-o2[0]).abs().max().item(); m2=(outputs[1]-o2[1]).abs().max().item()
    mg=[(a-b).abs().max().item() for a,b in zip(g,g2)]
    print(row['spec']['name'],'out',m1,m2,'grads',mg)
