"""Complete world-space eval3d RGB/alpha VJP entry. Editable.

Fast path: for the contract mode (global-shutter pinhole, use_hit_distance=False)
it calls the gsplat CUDA world-space rasterization forward/backward operators
directly, bypassing the generic Python wrapper and the autograd engine.
Every call still performs the full forward and all six VJPs from the actual
inputs; only input-independent configuration handles are cached.
A reference path (original wrapper + autograd.grad) is kept and used for any
input layout outside the fast path's supported set, so semantics are
preserved in all cases.
"""
import torch

_CMT = None
_UT = None
_FTHETA = None
_FWD = None
_BWD = None
_RS_GLOBAL = None
_SUPPORTED_CHANNELS = (
    1, 2, 3, 4, 5, 8, 9, 16, 17, 24, 32, 33, 64, 65, 128, 129, 256, 257, 512, 513,
)


def _init():
    """Resolve cached handles to the compiled CUDA ops (config only)."""
    global _CMT, _UT, _FTHETA, _FWD, _BWD, _RS_GLOBAL
    import gsplat.cuda._backend  # noqa: F401  (loads the compiled extension)
    from gsplat.cuda._backend import _C
    from gsplat.cuda._wrapper import (
        RollingShutterType,
        UnscentedTransformParameters,
        FThetaCameraDistortionParameters,
    )

    _CMT = int(_C.CameraModelType.PINHOLE)
    _UT = UnscentedTransformParameters()
    _FTHETA = FThetaCameraDistortionParameters()
    _FWD = torch.ops.gsplat.rasterize_to_pixels_from_world_3dgs_fwd
    _BWD = torch.ops.gsplat.rasterize_to_pixels_from_world_3dgs_bwd
    _RS_GLOBAL = int(RollingShutterType.GLOBAL)


_init()


def _c(t):
    return t if t.is_contiguous() else t.contiguous()


def _reference(inputs, meta, weights):
    from gsplat.cuda._wrapper import rasterize_to_pixels_eval3d, RollingShutterType

    outputs = rasterize_to_pixels_eval3d(
        **inputs,
        **meta,
        camera_model="pinhole",
        rolling_shutter=RollingShutterType.GLOBAL,
        use_hit_distance=False,
    )
    names = ["means", "quats", "scales", "colors", "opacities", "backgrounds"]
    gradients = torch.autograd.grad(
        outputs, tuple(inputs[n] for n in names), grad_outputs=weights
    )
    return outputs, gradients


def _fast_ok(inputs, meta):
    """Fast path applies only to the plain pinhole/global-shutter layout."""
    if set(inputs) - {"means", "quats", "scales", "colors", "opacities", "backgrounds"}:
        return False
    if set(meta) - {
        "viewmats",
        "Ks",
        "image_width",
        "image_height",
        "tile_size",
        "isect_offsets",
        "flatten_ids",
    }:
        return False
    colors = inputs["colors"]
    if colors.dtype != torch.float32 or colors.shape[-1] not in _SUPPORTED_CHANNELS:
        return False
    if colors.ndim != inputs["means"].ndim + 1:
        # packed color layout is not supported by the fast path
        return False
    for k in ("means", "quats", "scales", "opacities", "backgrounds"):
        if inputs[k].dtype != torch.float32:
            return False
    if not inputs["means"].is_cuda or not meta["viewmats"].is_cuda:
        return False
    return True


def run(inputs, meta, weights):
    if not _fast_ok(inputs, meta):
        return _reference(inputs, meta, weights)

    means = _c(inputs["means"])
    quats = _c(inputs["quats"])
    scales = _c(inputs["scales"])
    colors = _c(inputs["colors"])
    opacities = _c(inputs["opacities"])
    backgrounds = inputs.get("backgrounds")
    if backgrounds is not None:
        backgrounds = _c(backgrounds)
    viewmats = _c(meta["viewmats"])
    Ks = _c(meta["Ks"])
    isect_offsets = _c(meta["isect_offsets"])
    flatten_ids = _c(meta["flatten_ids"])
    width = int(meta["image_width"])
    height = int(meta["image_height"])
    tile_size = int(meta["tile_size"])

    render_colors, render_alphas, last_ids = _FWD(
        means, quats, scales, colors, opacities, backgrounds, None,
        width, height, tile_size, viewmats, None, Ks,
        _CMT, _UT, _RS_GLOBAL,
        None, None, None, None, _FTHETA, None, None,
        isect_offsets, flatten_ids, False, None, None,
    )

    v_colors_in = _c(weights[0])
    v_alphas_in = _c(weights[1])
    v_means, v_quats, v_scales, v_colors, v_opacities, _v_rays = _BWD(
        means, quats, scales, colors, opacities, backgrounds, None,
        width, height, tile_size, viewmats, None, Ks,
        _CMT, _UT, _RS_GLOBAL,
        None, None, None, None, _FTHETA, None, None,
        isect_offsets, flatten_ids, False,
        render_alphas, last_ids, v_colors_in, v_alphas_in, None,
    )

    # d/d backgrounds == (v_colors * (1 - alphas)).sum over pixels,
    # the same formula as the reference implementation.
    v_backgrounds = (v_colors_in * (1.0 - render_alphas).float()).sum(dim=(-3, -2))

    return (
        (render_colors, render_alphas),
        (v_means, v_quats, v_scales, v_colors, v_opacities, v_backgrounds),
    )
