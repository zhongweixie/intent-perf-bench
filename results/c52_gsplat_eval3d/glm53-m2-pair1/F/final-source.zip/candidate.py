"""Complete world-space eval3d RGB/alpha VJP entry (optimized).

Calls the gsplat CUDA forward/backward rasterization kernels directly with the
fixed global-shutter pinhole, use_hit_distance=False semantics, and reproduces
the parent implementation's outputs and six gradient tensors without going
through the autograd engine (the VJP is the same computation).
"""
import torch

_F = None  # cached lazily-initialized extension handles


def _init():
    from gsplat.cuda._wrapper import (
        _make_lazy_cuda_func,
        _make_lazy_cuda_obj,
        UnscentedTransformParameters,
        FThetaCameraDistortionParameters,
        RollingShutterType,
    )
    global _F
    _F = {
        "fwd": _make_lazy_cuda_func("rasterize_to_pixels_from_world_3dgs_fwd"),
        "bwd": _make_lazy_cuda_func("rasterize_to_pixels_from_world_3dgs_bwd"),
        "cam": _make_lazy_cuda_obj("CameraModelType.PINHOLE"),
        "ut": UnscentedTransformParameters(),
        "fth": FThetaCameraDistortionParameters(),
        "rs": RollingShutterType.GLOBAL,
    }


_SUPPORTED = (1, 2, 3, 4, 5, 8, 9, 16, 17, 24, 32, 33, 64, 65, 128, 129, 256, 257, 512, 513)


def _c(t):
    return t if t.is_contiguous() else t.contiguous()


def run(inputs, meta, weights):
    if _F is None:
        _init()
    fwd, bwd, cam, ut, fth, rs = _F["fwd"], _F["bwd"], _F["cam"], _F["ut"], _F["fth"], _F["rs"]

    means = _c(inputs["means"])
    quats = _c(inputs["quats"])
    scales = _c(inputs["scales"])
    colors = _c(inputs["colors"])
    opacities = _c(inputs["opacities"])
    backgrounds = _c(inputs["backgrounds"])
    viewmats = _c(meta["viewmats"])
    Ks = _c(meta["Ks"])
    isect_offsets = _c(meta["isect_offsets"])
    flatten_ids = _c(meta["flatten_ids"])
    width = meta["image_width"]
    height = meta["image_height"]
    tile_size = meta["tile_size"]

    # channel padding (same policy as the parent wrapper); a no-op for the
    # supported channel counts used by this path.
    channels = colors.shape[-1]
    padded_channels = 0
    if channels not in _SUPPORTED:
        padded_channels = (1 << (channels - 1).bit_length()) - channels
        colors = torch.cat(
            [
                colors[..., :-1],
                torch.zeros(*colors.shape[:-1], padded_channels, device=colors.device),
                colors[..., -1:],
            ],
            dim=-1,
        )
        backgrounds = torch.cat(
            [
                backgrounds,
                torch.zeros(*backgrounds.shape[:-1], padded_channels, device=backgrounds.device),
            ],
            dim=-1,
        )

    with torch.no_grad():
        render_colors, render_alphas, last_ids = fwd(
            means, quats, scales, colors, opacities, backgrounds, None,
            width, height, tile_size, viewmats, None, Ks, cam, ut, rs, None,
            None, None, None, fth, None, None,
            isect_offsets, flatten_ids, False, None, None,
        )

        v_render_colors = _c(weights[0])
        v_render_alphas = _c(weights[1])
        v_means, v_quats, v_scales, v_colors, v_opacities, _ = bwd(
            means, quats, scales, colors, opacities, backgrounds, None,
            width, height, tile_size, viewmats, None, Ks, cam, ut, rs, None,
            None, None, None, fth, None, None,
            isect_offsets, flatten_ids, False,
            render_alphas, last_ids, v_render_colors, v_render_alphas, None,
        )
        # gradient of the rendered background term (same formula as the parent)
        v_backgrounds = (v_render_colors * (1.0 - render_alphas).float()).sum(dim=(-3, -2))

    if padded_channels > 0:
        render_colors = torch.cat(
            [render_colors[..., : -padded_channels - 1], render_colors[..., -1:]], dim=-1
        )
        v_backgrounds = v_backgrounds[..., :-padded_channels]
        v_colors = v_colors[..., : -padded_channels - 1] if v_colors.shape[-1] == channels + padded_channels else v_colors

    return (render_colors, render_alphas), (
        v_means, v_quats, v_scales, v_colors, v_opacities, v_backgrounds,
    )
