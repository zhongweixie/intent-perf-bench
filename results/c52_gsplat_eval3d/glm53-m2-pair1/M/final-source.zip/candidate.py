"""Complete world-space eval3d RGB/alpha VJP entry. Editable.

Lean host path: calls the CUDA fwd/bwd rasterization ops directly (fixed
global-shutter pinhole, use_hit_distance=False, no rays/masks), avoiding the
generic Python wrapper and autograd graph construction. All outputs and the
six gradients are recomputed from the actual inputs on every call.
"""
import torch

_CACHE = {}


def _objs():
    """Build the constant C++ side-objects once (cached, input independent)."""
    if not _CACHE:
        from gsplat.cuda import _backend  # noqa: F401  (loads gsplat _C)
        from gsplat.cuda._wrapper import (
            _make_lazy_cuda_obj,
            _make_lazy_cuda_cls,
            RollingShutterType,
        )
        _CACHE["fwd"] = torch.ops.gsplat.rasterize_to_pixels_from_world_3dgs_fwd
        _CACHE["bwd"] = torch.ops.gsplat.rasterize_to_pixels_from_world_3dgs_bwd
        _CACHE["cm"] = _make_lazy_cuda_obj("CameraModelType.PINHOLE")
        _CACHE["ut"] = _make_lazy_cuda_cls("UnscentedTransformParameters")()
        _CACHE["ft"] = _make_lazy_cuda_cls("FThetaCameraDistortionParameters")()
        _CACHE["rs"] = int(RollingShutterType.GLOBAL)
    return _CACHE


def run(inputs, meta, weights):
    o = _objs()
    means = inputs["means"]
    quats = inputs["quats"]
    scales = inputs["scales"]
    colors = inputs["colors"]
    opacities = inputs["opacities"]
    backgrounds = inputs["backgrounds"]
    viewmats = meta["viewmats"]
    Ks = meta["Ks"]
    width = meta["image_width"]
    height = meta["image_height"]
    isect_offsets = meta["isect_offsets"]
    flatten_ids = meta["flatten_ids"]
    v_colors_in = weights[0]
    v_alphas_in = weights[1]

    render_colors, render_alphas, last_ids = o["fwd"](
        means, quats, scales, colors, opacities, backgrounds, None,
        width, height, meta["tile_size"], viewmats, None, Ks,
        o["cm"], o["ut"], o["rs"], None, None, None, None,
        o["ft"], None, None, isect_offsets, flatten_ids, False, None, None,
    )
    v_means, v_quats, v_scales, v_colors, v_opacities, _v_rays = o["bwd"](
        means, quats, scales, colors, opacities, backgrounds, None,
        width, height, meta["tile_size"], viewmats, None, Ks,
        o["cm"], o["ut"], o["rs"], None, None, None, None,
        o["ft"], None, None, isect_offsets, flatten_ids, False,
        render_alphas, last_ids, v_colors_in, v_alphas_in, None,
    )
    v_backgrounds = (v_colors_in * (1.0 - render_alphas)).sum(dim=(-3, -2))
    return (render_colors, render_alphas), (
        v_means, v_quats, v_scales, v_colors, v_opacities, v_backgrounds,
    )
