/*
 * Optimised implementation of the specified 17x17 Gaussian blur.
 *
 * The contract deliberately matters here: every pass is quantised to uint8,
 * and samples outside the image are clamped to the nearest edge pixel.  The
 * 2-D Gaussian is separable, so preserving those rules does not require 289
 * samples per output pixel: a horizontal 17-tap pass followed by a vertical
 * 17-tap pass is equivalent (up to harmless floating point roundoff).
 */
#include "solve.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define KDIM (2 * KERNEL_RADIUS + 1)

/* Only one half is retained: the Gaussian is symmetric. */
static float weight[KERNEL_RADIUS + 1];
static int kernel_ready;

/* Reusing scratch space also keeps allocation and page-fault cost out of the
   steady-state path (the benchmark calls this routine more than once). */
static float *horizontal;
static uint8_t *work_a, *work_b;
static size_t scratch_capacity;

static void build_kernel(void)
{
    if (kernel_ready) return;

    double raw[KDIM];
    double sum = 0.0;
    for (int i = 0; i < KDIM; ++i) {
        int d = i - KERNEL_RADIUS;
        raw[i] = exp(-(double)(d * d) / 18.0); /* 2 * sigma^2, sigma = 3 */
        sum += raw[i];
    }
    for (int i = 0; i <= KERNEL_RADIUS; ++i)
        weight[i] = (float)(raw[i] / sum);
    kernel_ready = 1;
}

static void ensure_scratch(size_t n)
{
    if (n <= scratch_capacity) return;

    float *new_horizontal = (float *)malloc(n * sizeof(*new_horizontal));
    uint8_t *new_a = (uint8_t *)malloc(n);
    uint8_t *new_b = (uint8_t *)malloc(n);
    if (!new_horizontal || !new_a || !new_b) {
        free(new_horizontal);
        free(new_a);
        free(new_b);
        fputs("OOM\n", stderr);
        exit(1);
    }
    free(horizontal);
    free(work_a);
    free(work_b);
    horizontal = new_horizontal;
    work_a = new_a;
    work_b = new_b;
    scratch_capacity = n;
}

/* Horizontal pass.  The central portion has no coordinate tests. */
static void horizontal_u8(const uint8_t * restrict in, float * restrict out,
                          int w, int h)
{
    for (int y = 0; y < h; ++y) {
        const uint8_t *row = in + (size_t)y * w;
        float *dst = out + (size_t)y * w;

        if (w <= 2 * KERNEL_RADIUS) {
            for (int x = 0; x < w; ++x) {
                float acc = weight[KERNEL_RADIUS] * row[x];
                for (int d = 1; d <= KERNEL_RADIUS; ++d) {
                    int l = x - d; if (l < 0) l = 0;
                    int r = x + d; if (r >= w) r = w - 1;
                    acc += weight[KERNEL_RADIUS - d] * (row[l] + row[r]);
                }
                dst[x] = acc;
            }
            continue;
        }

        for (int x = 0; x < KERNEL_RADIUS; ++x) {
            float acc = weight[KERNEL_RADIUS] * row[x];
            for (int d = 1; d <= KERNEL_RADIUS; ++d) {
                int l = x - d; if (l < 0) l = 0;
                acc += weight[KERNEL_RADIUS - d] * (row[l] + row[x + d]);
            }
            dst[x] = acc;
        }

        /* This loop has contiguous accesses and is the dominant hot path. */
#pragma GCC ivdep
        for (int x = KERNEL_RADIUS; x < w - KERNEL_RADIUS; ++x) {
            const uint8_t *p = row + x;
            float acc = weight[KERNEL_RADIUS] * p[0];
            for (int d = 1; d <= KERNEL_RADIUS; ++d)
                acc += weight[KERNEL_RADIUS - d] * (p[-d] + p[d]);
            dst[x] = acc;
        }

        for (int x = w - KERNEL_RADIUS; x < w; ++x) {
            float acc = weight[KERNEL_RADIUS] * row[x];
            for (int d = 1; d <= KERNEL_RADIUS; ++d) {
                int r = x + d; if (r >= w) r = w - 1;
                acc += weight[KERNEL_RADIUS - d] * (row[x - d] + row[r]);
            }
            dst[x] = acc;
        }
    }
}

/* Vertical pass plus the required per-pass uint8 rounding.  Traversing x in
   the inner loop makes each of the 17 source rows a sequential stream. */
static void vertical_to_u8(const float * restrict in, uint8_t * restrict out,
                           int w, int h)
{
    for (int y = 0; y < h; ++y) {
        uint8_t *dst = out + (size_t)y * w;
        for (int x = 0; x < w; ++x) {
            float acc = weight[KERNEL_RADIUS] * in[(size_t)y * w + x];
            for (int d = 1; d <= KERNEL_RADIUS; ++d) {
                int t = y - d; if (t < 0) t = 0;
                int b = y + d; if (b >= h) b = h - 1;
                acc += weight[KERNEL_RADIUS - d]
                     * (in[(size_t)t * w + x] + in[(size_t)b * w + x]);
            }
            int v = (int)(acc + 0.5f);
            if (v < 0) v = 0;
            if (v > 255) v = 255;
            dst[x] = (uint8_t)v;
        }
    }
}

void blur_image(const uint8_t *src, uint8_t *dst,
                int width, int height, int passes)
{
    const size_t n = (size_t)width * (size_t)height;
    build_kernel();

    if (passes <= 0) {
        memcpy(dst, src, n);
        return;
    }
    ensure_scratch(n);

    const uint8_t *input = src;
    for (int p = 0; p < passes; ++p) {
        /* Writing the final pass directly avoids an otherwise full-image copy. */
        uint8_t *output = (p == passes - 1) ? dst : ((p & 1) ? work_b : work_a);
        horizontal_u8(input, horizontal, width, height);
        vertical_to_u8(horizontal, output, width, height);
        input = output;
    }
}
