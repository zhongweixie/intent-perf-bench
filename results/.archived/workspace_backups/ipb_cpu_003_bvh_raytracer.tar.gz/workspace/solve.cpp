// optimized_solve.cpp — BVH ray tracer with a hot, division-late triangle test.
#include "solve.h"
#include <cstdlib>
#include <algorithm>
#include <cfloat>

struct BVHNode {
    float3 aabbMin, aabbMax;
    int leftFirst;
    int triCount;                 // 0 = internal node
    bool isLeaf() const { return triCount > 0; }
};

static Tri* g_tris;
static int g_N;
static int* g_idx;
static BVHNode* g_bvh;
static int g_nodeCount;

// These are immutable per triangle.  Keeping them contiguous and precomputing
// the edges removes two subtractions from every candidate triangle test.
struct AccelTri { float3 v0, e1, e2; };
static AccelTri* g_accel;

static inline float HalfArea(const float3& mn, const float3& mx) {
    const float3 e = mx - mn;
    return e.x * e.y + e.y * e.z + e.z * e.x;
}

static inline float IntersectAABB(const Ray& ray, const float3& bmin,
                                  const float3& bmax) {
    float lo = 0.0f, hi = ray.t;
    const float o[3] = {ray.O.x, ray.O.y, ray.O.z};
    const float d[3] = {ray.D.x, ray.D.y, ray.D.z};
    const float mn[3] = {bmin.x, bmin.y, bmin.z};
    const float mx[3] = {bmax.x, bmax.y, bmax.z};
    for (int k = 0; k < 3; ++k) {
        if (d[k] == 0.0f) {
            if (o[k] < mn[k] || o[k] > mx[k]) return 1e30f;
        } else {
            float a = (mn[k] - o[k]) / d[k];
            float b = (mx[k] - o[k]) / d[k];
            if (a > b) std::swap(a, b);
            if (a > lo) lo = a;
            if (b < hi) hi = b;
            if (hi < lo) return 1e30f;
        }
    }
    return (hi > 0.0f && lo < ray.t) ? lo : 1e30f;
}

// Möller–Trumbore, specialized for one preprocessed triangle.
//
// Do not form 1/det until the test has passed.  For the usual primary-ray
// workload most candidates miss on u or v, so this removes a costly division
// from those misses while preserving the two-sided (non-culling) test.  The
// barycentric numerators are compared in determinant space:
//   det > 0: 0 <= uNum, vNum and uNum+vNum <= det
//   det < 0: the inequalities are reversed.
// Consequently only a genuine hit pays for the final division.
static inline void IntersectAccelTri(Ray& ray, const AccelTri& tri) {
    const float sx = ray.O.x - tri.v0.x;
    const float sy = ray.O.y - tri.v0.y;
    const float sz = ray.O.z - tri.v0.z;

    // h = D x e2
    const float hx = ray.D.y * tri.e2.z - ray.D.z * tri.e2.y;
    const float hy = ray.D.z * tri.e2.x - ray.D.x * tri.e2.z;
    const float hz = ray.D.x * tri.e2.y - ray.D.y * tri.e2.x;
    const float det = tri.e1.x * hx + tri.e1.y * hy + tri.e1.z * hz;
    if (det > -1e-7f && det < 1e-7f) return;

    const float uNum = sx * hx + sy * hy + sz * hz;
    const float qx = sy * tri.e1.z - sz * tri.e1.y;
    const float qy = sz * tri.e1.x - sx * tri.e1.z;
    const float qz = sx * tri.e1.y - sy * tri.e1.x;
    const float vNum = ray.D.x * qx + ray.D.y * qy + ray.D.z * qz;

    if (det > 0.0f) {
        if (uNum < 0.0f || uNum > det || vNum < 0.0f ||
            uNum + vNum > det) return;
    } else {
        if (uNum > 0.0f || uNum < det || vNum > 0.0f ||
            uNum + vNum < det) return;
    }

    const float tNum = tri.e2.x * qx + tri.e2.y * qy + tri.e2.z * qz;

    // Test the ray interval in the same signed determinant space.  In
    // particular, occluded candidates no longer perform a division merely to
    // discover that their t is beyond the closest hit already in ray.t.
    if (det > 0.0f) {
        if (tNum <= 1e-7f * det || tNum >= ray.t * det) return;
    } else {
        if (tNum >= 1e-7f * det || tNum <= ray.t * det) return;
    }
    ray.t = tNum / det;
}

static void RecomputeBounds(int nodeIdx) {
    BVHNode& n = g_bvh[nodeIdx];
    n.aabbMin = {1e30f, 1e30f, 1e30f};
    n.aabbMax = {-1e30f, -1e30f, -1e30f};
    for (int i = n.leftFirst; i < n.leftFirst + n.triCount; ++i) {
        const Tri& t = g_tris[g_idx[i]];
        n.aabbMin = fminf3(n.aabbMin, fminf3(t.vertex0, fminf3(t.vertex1, t.vertex2)));
        n.aabbMax = fmaxf3(n.aabbMax, fmaxf3(t.vertex0, fmaxf3(t.vertex1, t.vertex2)));
    }
}

static const int BINS = 8;
struct Bin { float3 mn, mx; int count; };

static void Subdivide(int nodeIdx) {
    BVHNode& node = g_bvh[nodeIdx];
    if (node.triCount <= 2) return;
    const float3 extent = node.aabbMax - node.aabbMin;
    const float parentArea = HalfArea(node.aabbMin, node.aabbMax);
    const float leafCost = static_cast<float>(node.triCount);
    float bestCost = leafCost;
    int bestAxis = -1;
    float bestSplit = 0.0f;

    for (int axis = 0; axis < 3; ++axis) {
        if (extent[axis] < 1e-6f) continue;
        const float scale = BINS / extent[axis];
        Bin bins[BINS];
        for (Bin& b : bins) { b.mn={1e30f,1e30f,1e30f}; b.mx={-1e30f,-1e30f,-1e30f}; b.count=0; }
        for (int i=node.leftFirst; i<node.leftFirst+node.triCount; ++i) {
            const Tri& t=g_tris[g_idx[i]];
            int bi=std::min(BINS-1,(int)((t.centroid[axis]-node.aabbMin[axis])*scale));
            Bin& b=bins[bi]; ++b.count;
            b.mn=fminf3(b.mn,fminf3(t.vertex0,fminf3(t.vertex1,t.vertex2)));
            b.mx=fmaxf3(b.mx,fmaxf3(t.vertex0,fmaxf3(t.vertex1,t.vertex2)));
        }
        float3 lmn[BINS-1],lmx[BINS-1]; int lcnt[BINS-1];
        float3 mn={1e30f,1e30f,1e30f},mx={-1e30f,-1e30f,-1e30f}; int cnt=0;
        for(int i=0;i<BINS-1;++i){cnt+=bins[i].count;mn=fminf3(mn,bins[i].mn);mx=fmaxf3(mx,bins[i].mx);lmn[i]=mn;lmx[i]=mx;lcnt[i]=cnt;}
        mn={1e30f,1e30f,1e30f};mx={-1e30f,-1e30f,-1e30f};cnt=0;
        for(int i=BINS-2;i>=0;--i){cnt+=bins[i+1].count;mn=fminf3(mn,bins[i+1].mn);mx=fmaxf3(mx,bins[i+1].mx);
            float cost=(lcnt[i]*HalfArea(lmn[i],lmx[i])+cnt*HalfArea(mn,mx))/parentArea;
            if(cost<bestCost){bestCost=cost;bestAxis=axis;bestSplit=node.aabbMin[axis]+(i+1)*extent[axis]/BINS;}
        }
    }
    if(bestAxis<0) return;
    int i=node.leftFirst,j=i+node.triCount-1;
    while(i<=j){if(g_tris[g_idx[i]].centroid[bestAxis]<bestSplit)++i;else std::swap(g_idx[i],g_idx[j--]);}
    const int leftCount=i-node.leftFirst;
    if(leftCount==0||leftCount==node.triCount)return;
    const int leftIdx=g_nodeCount++,rightIdx=g_nodeCount++;
    g_bvh[leftIdx]=BVHNode{{},{},node.leftFirst,leftCount};
    g_bvh[rightIdx]=BVHNode{{},{},i,node.triCount-leftCount};
    node.leftFirst=leftIdx;node.triCount=0;
    RecomputeBounds(leftIdx);RecomputeBounds(rightIdx);Subdivide(leftIdx);Subdivide(rightIdx);
}

static inline float IntersectAABBInv(const Ray& ray,const float3& invD,
                                     const float3& mn,const float3& mx){
    float tx1=(mn.x-ray.O.x)*invD.x,tx2=(mx.x-ray.O.x)*invD.x;
    float lo=std::min(tx1,tx2),hi=std::max(tx1,tx2);
    float ty1=(mn.y-ray.O.y)*invD.y,ty2=(mx.y-ray.O.y)*invD.y;
    lo=std::max(lo,std::min(ty1,ty2));hi=std::min(hi,std::max(ty1,ty2));
    float tz1=(mn.z-ray.O.z)*invD.z,tz2=(mx.z-ray.O.z)*invD.z;
    lo=std::max(lo,std::min(tz1,tz2));hi=std::min(hi,std::max(tz1,tz2));
    return(hi>=lo&&hi>0.0f&&lo<ray.t)?lo:1e30f;
}

static void TraverseParallel(Ray& ray,int ni){
    const BVHNode& n=g_bvh[ni]; if(IntersectAABB(ray,n.aabbMin,n.aabbMax)>=ray.t)return;
    if(n.isLeaf()){for(int i=n.leftFirst;i<n.leftFirst+n.triCount;++i)IntersectAccelTri(ray,g_accel[i]);}
    else{TraverseParallel(ray,n.leftFirst);TraverseParallel(ray,n.leftFirst+1);}
}
static void Traverse(Ray& ray,const float3& invD,int ni){
    const BVHNode& n=g_bvh[ni];
    if(n.isLeaf()){for(int i=n.leftFirst;i<n.leftFirst+n.triCount;++i)IntersectAccelTri(ray,g_accel[i]);return;}
    const int l=n.leftFirst,r=l+1; const float lt=IntersectAABBInv(ray,invD,g_bvh[l].aabbMin,g_bvh[l].aabbMax),rt=IntersectAABBInv(ray,invD,g_bvh[r].aabbMin,g_bvh[r].aabbMax);
    if(lt<rt){if(lt<ray.t)Traverse(ray,invD,l);if(rt<ray.t)Traverse(ray,invD,r);}
    else{if(rt<ray.t)Traverse(ray,invD,r);if(lt<ray.t)Traverse(ray,invD,l);}
}

void Build(Tri* tris,int N){
    g_tris=tris;g_N=N;g_idx=new int[N];for(int i=0;i<N;++i)g_idx[i]=i;
    g_bvh=new BVHNode[2*N];g_nodeCount=1;g_bvh[0]=BVHNode{{},{},0,N};RecomputeBounds(0);Subdivide(0);
    g_accel=new AccelTri[N];for(int i=0;i<N;++i){const Tri&t=g_tris[g_idx[i]];g_accel[i]={t.vertex0,t.vertex1-t.vertex0,t.vertex2-t.vertex0};}
}
bool Intersect(Ray& ray){
    if(g_N==0)return false;
    if(ray.D.x==0.0f||ray.D.y==0.0f||ray.D.z==0.0f){TraverseParallel(ray,0);return ray.t<1e30f;}
    const float3 invD={1.0f/ray.D.x,1.0f/ray.D.y,1.0f/ray.D.z};
    if(IntersectAABBInv(ray,invD,g_bvh[0].aabbMin,g_bvh[0].aabbMax)<ray.t)Traverse(ray,invD,0);
    return ray.t<1e30f;
}
