/* Cache-friendly grouped hash join for the bounded key domain. */
#include "solve.h"

#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>

/*
 * Keys are documented to be in [0, KEY_RANGE).  Consequently a direct
 * address table is cheaper than hashing: there is no hash computation or
 * collision chain to walk.  More importantly, do not probe the build table
 * once per S row.  Aggregate both relations by key, then combine the two
 * compact arrays in one sequential pass.  This turns the five-million-row
 * random lookup phase into a streaming pass over KEY_RANGE entries.
 *
 * For a key k, if R has nr rows and payload sum pr, and S has ns rows and
 * payload sum ps, its contribution is:
 *
 *   matches  = nr * ns
 *   checksum = pr * ns + ps * nr
 *
 * All arithmetic below deliberately uses the same unsigned 64-bit modular
 * arithmetic as the specified per-pair checksum.
 */
void hash_join(const Row *r, int r_count, const Row *s, int s_count,
               JoinResult *out)
{
    if (r_count <= 0 || s_count <= 0) {
        out->match_count = 0;
        out->checksum = 0;
        return;
    }

    const size_t nkeys = (size_t)KEY_RANGE;
    uint64_t *r_rows = (uint64_t *)calloc(nkeys, sizeof(*r_rows));
    uint64_t *r_sums = (uint64_t *)calloc(nkeys, sizeof(*r_sums));
    uint64_t *s_rows = (uint64_t *)calloc(nkeys, sizeof(*s_rows));
    uint64_t *s_sums = (uint64_t *)calloc(nkeys, sizeof(*s_sums));

    if (r_rows != NULL && r_sums != NULL &&
        s_rows != NULL && s_sums != NULL) {
        for (int i = 0; i < r_count; ++i) {
            const size_t key = (size_t)(uint32_t)r[i].key;
            ++r_rows[key];
            r_sums[key] += (uint64_t)(uint32_t)r[i].payload;
        }

        /* This is the only random-looking operation, but it is a compact
         * 400 KB pair of arrays and avoids random reads during probing. */
        for (int j = 0; j < s_count; ++j) {
            const size_t key = (size_t)(uint32_t)s[j].key;
            ++s_rows[key];
            s_sums[key] += (uint64_t)(uint32_t)s[j].payload;
        }

        int64_t match_count = 0;
        uint64_t checksum = 0;
        for (size_t key = 0; key < nkeys; ++key) {
            const uint64_t nr = r_rows[key];
            const uint64_t ns = s_rows[key];
            if (nr != 0 && ns != 0) {
                match_count += (int64_t)(nr * ns);
                checksum += r_sums[key] * ns + s_sums[key] * nr;
            }
        }

        free(r_rows);
        free(r_sums);
        free(s_rows);
        free(s_sums);
        out->match_count = match_count;
        out->checksum = checksum;
        return;
    }

    free(r_rows);
    free(r_sums);
    free(s_rows);
    free(s_sums);

    /* Exceptional OOM fallback.  Keep the exact reference semantics. */
    int64_t match_count = 0;
    uint64_t checksum = 0;
    for (int j = 0; j < s_count; ++j) {
        for (int i = 0; i < r_count; ++i) {
            if (r[i].key == s[j].key) {
                ++match_count;
                checksum += (uint64_t)(uint32_t)r[i].payload
                          + (uint64_t)(uint32_t)s[j].payload;
            }
        }
    }
    out->match_count = match_count;
    out->checksum = checksum;
}
