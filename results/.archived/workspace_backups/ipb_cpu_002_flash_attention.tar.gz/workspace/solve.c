/*
 * solve.c — tiled Flash Attention implementation.
 *
 * The original implementation spent most of its time materialising the
 * score/probability matrices and repeatedly calling scalar expf().  This
 * version keeps the online-softmax algorithm, tiles the work, and uses an
 * AVX2 exp approximation for the hot probability loop.
 */

#include "solve.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <float.h>

#ifdef __AVX2__
#  include <immintrin.h>
#endif

#define Br 32
#define Bc 32

#ifdef __AVX2__

static inline float hsum8(__m256 v)
{
    __m128 lo = _mm256_castps256_ps128(v);
    __m128 hi = _mm256_extractf128_ps(v, 1);
    __m128 s = _mm_add_ps(lo, hi);
    s = _mm_hadd_ps(s, s);
    s = _mm_hadd_ps(s, s);
    return _mm_cvtss_f32(s);
}

/*
 * exp(x), vectorised.  Range reduction leaves r in approximately
 * [-ln(2)/2, ln(2)/2], where the seventh-order Taylor polynomial is very
 * accurate.  Inputs to this routine are normally <= 0 (softmax after the
 * row maximum); clamping also prevents invalid exponent-bit construction for
 * very negative scores and gives the expected float underflow behaviour.
 */
static inline __m256 exp_avx(__m256 x)
{
    const __m256 ln2 = _mm256_set1_ps(0.6931471805599453f);
    const __m256 inv_ln2 = _mm256_set1_ps(1.4426950408889634f);
    const __m256 lo = _mm256_set1_ps(-87.33654475f);
    const __m256 hi = _mm256_set1_ps(88.0f);
    const __m256 one = _mm256_set1_ps(1.0f);

    x = _mm256_max_ps(lo, _mm256_min_ps(hi, x));
    __m256 k = _mm256_round_ps(_mm256_mul_ps(x, inv_ln2),
                               _MM_FROUND_TO_NEAREST_INT | _MM_FROUND_NO_EXC);
    __m256 r = _mm256_fnmadd_ps(k, ln2, x);

    __m256 p = _mm256_set1_ps(1.0f / 5040.0f);
    p = _mm256_fmadd_ps(p, r, _mm256_set1_ps(1.0f / 720.0f));
    p = _mm256_fmadd_ps(p, r, _mm256_set1_ps(1.0f / 120.0f));
    p = _mm256_fmadd_ps(p, r, _mm256_set1_ps(1.0f / 24.0f));
    p = _mm256_fmadd_ps(p, r, _mm256_set1_ps(1.0f / 6.0f));
    p = _mm256_fmadd_ps(p, r, _mm256_set1_ps(0.5f));
    p = _mm256_fmadd_ps(p, r, one);
    p = _mm256_fmadd_ps(p, r, one);

    __m256i ki = _mm256_add_epi32(_mm256_cvtps_epi32(k),
                                  _mm256_set1_epi32(127));
    ki = _mm256_slli_epi32(ki, 23);
    return _mm256_mul_ps(p, _mm256_castsi256_ps(ki));
}

static inline float dot_avx(const float *a, const float *b, int d)
{
    __m256 acc = _mm256_setzero_ps();
    int k = 0;
    for (; k + 7 < d; k += 8)
        acc = _mm256_fmadd_ps(_mm256_loadu_ps(a + k),
                              _mm256_loadu_ps(b + k), acc);
    float result = hsum8(acc);
    for (; k < d; ++k) result += a[k] * b[k];
    return result;
}

#else
static inline float dot_avx(const float *a, const float *b, int d)
{
    float acc = 0.0f;
    for (int k = 0; k < d; ++k) acc += a[k] * b[k];
    return acc;
}
#endif

void attention(const float * restrict Q, const float * restrict K,
               const float * restrict V, float * restrict output,
               int n, int d)
{
    const float scale = 1.0f / sqrtf((float)d);
    float *m_st = malloc(Br * sizeof(*m_st));
    float *l_st = malloc(Br * sizeof(*l_st));
    float *O_st = malloc((size_t)Br * d * sizeof(*O_st));
    float *SP = malloc((size_t)Br * Bc * sizeof(*SP));
    if (!m_st || !l_st || !O_st || !SP) {
        free(m_st); free(l_st); free(O_st); free(SP);
        return;
    }

    for (int ib = 0; ib < n; ib += Br) {
        int ilen = (ib + Br <= n) ? Br : n - ib;
        for (int i = 0; i < ilen; ++i) {
            m_st[i] = -FLT_MAX;
            l_st[i] = 0.0f;
        }
        memset(O_st, 0, (size_t)ilen * d * sizeof(*O_st));

        for (int jb = 0; jb < n; jb += Bc) {
            int jlen = (jb + Bc <= n) ? Bc : n - jb;
            for (int i = 0; i < ilen; ++i) {
                const float *qi = Q + (ib + i) * d;
                for (int j = 0; j < jlen; ++j)
                    SP[i * Bc + j] = dot_avx(qi, K + (jb + j) * d, d) * scale;
            }

            for (int i = 0; i < ilen; ++i) {
                float *oi = O_st + i * d;
                float *prob = SP + i * Bc;
                float m_new = m_st[i];
                for (int j = 0; j < jlen; ++j)
                    if (prob[j] > m_new) m_new = prob[j];

                /* This is one exp per tile row, not the hot O(n^2) loop. */
                float rescale = expf(m_st[i] - m_new);
                float l_sum = 0.0f;
#ifdef __AVX2__
                __m256 vm = _mm256_set1_ps(m_new);
                __m256 vsum = _mm256_setzero_ps();
                int j = 0;
                for (; j + 7 < jlen; j += 8) {
                    __m256 s = _mm256_loadu_ps(prob + j);
                    __m256 p = exp_avx(_mm256_sub_ps(s, vm));
                    _mm256_storeu_ps(prob + j, p);
                    vsum = _mm256_add_ps(vsum, p);
                }
                l_sum = hsum8(vsum);
                for (; j < jlen; ++j) {
                    prob[j] = expf(prob[j] - m_new);
                    l_sum += prob[j];
                }
#else
                for (int j = 0; j < jlen; ++j) {
                    prob[j] = expf(prob[j] - m_new);
                    l_sum += prob[j];
                }
#endif

                for (int k = 0; k < d; ++k) oi[k] *= rescale;
                for (int j = 0; j < jlen; ++j) {
                    float p = prob[j];
                    const float *vj = V + (jb + j) * d;
#ifdef __AVX2__
                    __m256 vp = _mm256_set1_ps(p);
                    int k = 0;
                    for (; k + 7 < d; k += 8) {
                        __m256 ov = _mm256_loadu_ps(oi + k);
                        __m256 vv = _mm256_loadu_ps(vj + k);
                        _mm256_storeu_ps(oi + k, _mm256_fmadd_ps(vp, vv, ov));
                    }
                    for (; k < d; ++k) oi[k] += p * vj[k];
#else
                    for (int k = 0; k < d; ++k) oi[k] += p * vj[k];
#endif
                }
                l_st[i] = l_st[i] * rescale + l_sum;
                m_st[i] = m_new;
            }
        }

        for (int i = 0; i < ilen; ++i) {
            float inv_l = 1.0f / l_st[i];
            float *oi = O_st + i * d;
            float *dst = output + (ib + i) * d;
            for (int k = 0; k < d; ++k) dst[k] = oi[k] * inv_l;
        }
    }
    free(m_st); free(l_st); free(O_st); free(SP);
}
